#ifndef LutusMegaBot_h
#define LutusMegaBot_h
////////////////////////////////////////////
////////////////////////////////////////////
//////  www.lotus-arduibot.com   //////////
///////////////////////////////////////////
#include "LotusMegaMotor.h"
#include "LotusMegaServo.h"
#include "LotusMegaSound.h"
#include "LotusIO.h"
#include "LotusOLED.h"
#include "LotusCompass.h"
#include "MechaQMC5883.h"
//#include "Wire.h"
/////////////////////////////////


#endif
